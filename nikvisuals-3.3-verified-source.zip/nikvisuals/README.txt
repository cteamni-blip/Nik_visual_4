Nik Visuals 3.3

- Cooldown HUD: icon + name + seconds (>=1s only)
- Swap ring: black-green, particles, hover select
- Swap only Funtime talismans/spheres from fixed list
- While holding swap key: movement keys released + velocity zeroed
- Short freeze after swap (anti-kick)

Build: gradlew.bat build
