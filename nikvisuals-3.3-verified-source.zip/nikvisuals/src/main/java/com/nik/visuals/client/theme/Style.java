package com.nik.visuals.client.theme;

/** Black / gray / green palette */
public final class Style {
    private Style() {}

    public static final int BG_DEEP     = 0xF0080808;
    public static final int PANEL      = 0xF0121212;
    public static final int PANEL2     = 0xE8181818;
    public static final int GLASS      = 0xCC0C0C0C;
    public static final int ACCENT     = 0xFF3DCC7A;
    public static final int ACCENT_DIM = 0x8833AA66;
    public static final int ACCENT_GLOW= 0x4033CC77;
    public static final int TEXT       = 0xFFE8E8E8;
    public static final int TEXT_DIM   = 0xFF888888;
    public static final int DANGER     = 0xFFFF5555;
    public static final int WARN       = 0xFFDDBB44;
    public static final int OK         = 0xFF55CC88;
    public static final int ROW_HOV    = 0x2822AA55;
    public static final int DIVIDER    = 0x3322AA55;
    public static final int TRACK_OFF  = 0xFF2A2A2A;
    public static final int KNOB       = 0xFFF0F0F0;

    public static int alpha(int argb, float a) {
        int aa = Math.max(0, Math.min(255, (int) (((argb >>> 24) & 0xFF) * a)));
        return (aa << 24) | (argb & 0x00FFFFFF);
    }

    public static int solidAlpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0x00FFFFFF);
    }
}
