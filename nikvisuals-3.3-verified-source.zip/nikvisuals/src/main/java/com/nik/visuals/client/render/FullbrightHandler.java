package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

@Environment(EnvType.CLIENT)
public class FullbrightHandler {
    private Double savedGamma;

    public void tick(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;
        try {
            SimpleOption<Double> gamma = mc.options.getGamma();
            if (ModConfig.fullbright) {
                if (savedGamma == null) {
                    double v = gamma.getValue();
                    // never store illegal values
                    savedGamma = (v >= 0.0 && v <= 1.0) ? v : 1.0;
                }
                // max legal gamma + LightTextureMixin does the real fullbright
                if (gamma.getValue() < 1.0) {
                    gamma.setValue(1.0);
                }
            } else if (savedGamma != null) {
                double restore = Math.max(0.0, Math.min(1.0, savedGamma));
                gamma.setValue(restore);
                savedGamma = null;
            }
        } catch (Throwable ignored) {}
    }
}
