package com.nik.visuals.client.slot;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.slot.CooldownQuery;
import com.nik.visuals.client.slot.HealCooldowns;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class SlotTimerRenderer {
    public void tick(MinecraftClient mc) {
        HealCooldowns.tick();
    }

    public static void renderAfterHotbar(DrawContext g, float partialTick) {
        if (!ModConfig.slotTimer) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.currentScreen != null) {
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int hotbarLeft = sw / 2 - 91;
        int hotbarY = sh - 22;
        for (int i = 0; i < 9; ++i) {
            String text;
            ItemStack stack = player.getInventory().getStack(i);
            float[] cd = CooldownQuery.query(player, stack, partialTick);
            if (cd == null) continue;
            float progress = cd[0];
            float seconds = cd[1];
            int slotX = hotbarLeft + i * 20 + 3;
            int slotY = hotbarY + 3;
            if (ModConfig.slotTimerOverlay) {
                int h = Math.max(1, (int)(16.0f * progress));
                g.fill(slotX, slotY + (16 - h), slotX + 16, slotY + 16, -1728053248);
            }
            String string = text = seconds >= 10.0f ? String.valueOf((int)Math.ceil(seconds)) : String.format("%.1f", Float.valueOf(seconds));
            int color = progress <= 0.33f ? -11141291 : (progress <= 0.66f ? -171 : -43691);
            g.getMatrices().pushMatrix();
            g.getMatrices().translate(0.0f, 0.0f);
            float scale = ModConfig.slotTimerScale;
            int tw = (int)((float)mc.textRenderer.getWidth(text) * scale);
                        float f = slotX + 17 - tw;
            Objects.requireNonNull(mc.textRenderer);
            g.getMatrices().translate(f)(slotY + 17 - (int)(9.0f * scale)), 0.0f);
            g.getMatrices().scale(scale, scale);
            g.drawText(mc.textRenderer);
            g.drawText(mc.textRenderer, text, 0, 0, color, false);
            g.getMatrices().popMatrix();
        }
    }
}

