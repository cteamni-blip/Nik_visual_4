package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class CooldownHudRenderer {
    private float appear;
    private int lastX, lastY, lastW, lastH;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    private static class Row {
        final ItemStack stack;
        final String name;
        final float seconds;
        Row(ItemStack s, String n, float sec) { stack = s; name = n; seconds = sec; }
    }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.cooldownHud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;

        List<Row> rows = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            float progress = 0f;
            try {
                progress = p.getItemCooldownManager().getCooldownProgress(st, pt);
            } catch (Throwable ignored) {}
            if (progress <= 0.01f) continue;
            // approximate remaining seconds from progress (vanilla cool-downs often ~1-8s)
            float sec = progress * 8f;
            // prefer exact if available via remaining ticks - rough is fine
            if (sec < 1.0f) continue; // hide sub-second
            String name = st.getName().getString();
            if (name.length() > 18) name = name.substring(0, 17) + "…";
            // dedupe by display name
            boolean dup = false;
            for (Row r : rows) {
                if (r.name.equals(name)) { dup = true; break; }
            }
            if (dup) continue;
            rows.add(new Row(st.copy(), name, sec));
            if (rows.size() >= 8) break;
        }

        boolean show = !rows.isEmpty() || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.15f);
        if (appear < 0.02f) return;

        float a = Anim.easeOutCubic(appear);
        int x = (int) (ModConfig.cooldownHudX * mc.getWindow().getScaledWidth());
        int y = (int) (ModConfig.cooldownHudY * mc.getWindow().getScaledHeight());

        if (rows.isEmpty() && ModConfig.layoutEdit) {
            lastX = x; lastY = y; lastW = 120; lastH = 28;
            GuiDraw.glassPanel(g, x, y, 120, 28, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
            g.drawText(mc.textRenderer, "Кулдауны", x + 12, y + 10, Style.alpha(Style.TEXT_DIM, a), false);
            return;
        }
        if (rows.isEmpty()) return;

        int lineH = 18;
        int w = 130;
        for (Row r : rows) {
            w = Math.max(w, 28 + mc.textRenderer.getWidth(r.name) + 36);
        }
        int h = 8 + rows.size() * lineH;
        lastX = x; lastY = y; lastW = w; lastH = h;

        // slide-in
        int drawX = x + (int) ((1f - a) * -8);
        GuiDraw.glassPanel(g, drawX, y, w, h, 10, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));

        int row = 0;
        for (Row r : rows) {
            int ry = y + 5 + row * lineH;
            GuiDraw.fillRounded(g, drawX + 4, ry, 14, 14, 4, Style.alpha(Style.GLASS, a));
            g.drawItem(r.stack, drawX + 5, ry);
            g.drawText(mc.textRenderer, r.name, drawX + 22, ry + 3, Style.alpha(Style.TEXT, a), false);
            String t = String.format("%.0fс", Math.ceil(r.seconds));
            int tw = mc.textRenderer.getWidth(t);
            g.drawText(mc.textRenderer, t, drawX + w - 8 - tw, ry + 3, Style.alpha(Style.ACCENT, a), false);
            row++;
        }
    }
}
