package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class AmbienceRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.ambience) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null) {
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float intensity = Math.max(0.05f, Math.min(1.0f, ModConfig.ambienceIntensity));
        int edge = Math.max(12, Math.min(sw, sh) / 8);
        for (int i = 0; i < edge; ++i) {
            float t = 1.0f - (float)i / (float)edge;
            int a = (int)(t * t * 28.0f * intensity);
            if (a < 1) continue;
            int c = a << 24 | 0x9B6DFF;
            g.fill(0, i, sw, i + 1, c);
            g.fill(0, sh - i - 1, sw, sh - i, c);
            g.fill(i, 0, i + 1, sh, c);
            g.fill(sw - i - 1, 0, sw - i, sh, c);
        }
    }
}

