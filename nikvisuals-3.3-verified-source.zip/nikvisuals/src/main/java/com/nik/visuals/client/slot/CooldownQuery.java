package com.nik.visuals.client.slot;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public final class CooldownQuery {
    private CooldownQuery() {}

    /** Returns {progress 0..1, seconds} or null if no cooldown. */
    public static float[] query(ClientPlayerEntity player, ItemStack stack, float partial) {
        if (player == null || stack == null || stack.isEmpty()) return null;
        try {
            float progress = player.getItemCooldownManager().getCooldownProgress(stack, partial);
            if (progress <= 0.05f) {
                float[] heal = HealCooldowns.queryPotionHeal();
                if (heal != null && HealCooldowns.matchesPotionSlot(stack)) return heal;
                return null;
            }
            float seconds = Math.max(0.1f, progress * 8f);
            return new float[]{progress, seconds};
        } catch (Throwable t) {
            return null;
        }
    }
}
