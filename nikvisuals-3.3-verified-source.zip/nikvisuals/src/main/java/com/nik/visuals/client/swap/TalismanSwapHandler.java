package com.nik.visuals.client.swap;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Environment(EnvType.CLIENT)
public class TalismanSwapHandler {
    /** Exact Funtime names (normalized lowercase compare) */
    private static final String[] ALLOWED = {
            "талисман крушителя",
            "талисман карателя",
            "талисман раздора",
            "талисман тирана",
            "талисман ярости",
            "талисман вихря",
            "талисман мрака",
            "талисман демона",
            "сфера афины",
            "сфера титана",
            "сфера хаоса",
            "сфера сатира",
            "сфера бестии",
            "сфера ареса",
            "сфера гидры",
            "сфера икара",
            "сфера эрида"
    };

    private static final long SWAP_COOLDOWN_MS = 900L;
    private long lastSwapMs;
    private boolean wasDown;
    private int hovered = -1;
    private final List<Candidate> candidates = new ArrayList<>();
    private float openAnim;
    private float spin;
    private String statusMsg;
    private long statusUntil;
    private int freezeTicks; // stop input while swapping

    public void tick(MinecraftClient mc, boolean keyDown) {
        if (freezeTicks > 0) {
            freezeTicks--;
            stopMovement(mc);
        }

        if (!ModConfig.talismanSwap || mc.player == null || mc.currentScreen != null) {
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.2f);
            return;
        }

        if (keyDown) {
            if (!wasDown) {
                rebuildCandidates(mc.player);
                hovered = candidates.isEmpty() ? -1 : 0;
            }
            updateHover(mc);
            openAnim = Math.min(1f, openAnim + 0.18f);
            spin += 0.04f;
            stopMovement(mc); // hold still while menu open — anti-kick
            wasDown = true;
        } else {
            if (wasDown && hovered >= 0 && hovered < candidates.size()) {
                trySwap(mc, candidates.get(hovered));
            }
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.22f);
        }
    }

    private void stopMovement(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.options == null) return;
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            // zero velocity client-side for a moment
            mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        } catch (Throwable ignored) {}
    }

    private void trySwap(MinecraftClient mc, Candidate c) {
        long now = System.currentTimeMillis();
        if (now - lastSwapMs < SWAP_COOLDOWN_MS) {
            statusMsg = "§cПодожди…";
            statusUntil = now + 700;
            return;
        }
        stopMovement(mc);
        freezeTicks = 8; // ~0.4s freeze after swap
        if (swapToOffhand(mc, c)) {
            lastSwapMs = now;
            statusMsg = "§a" + c.stack.getName().getString();
            statusUntil = now + 900;
        } else {
            statusMsg = "§cНе вышло";
            statusUntil = now + 700;
        }
    }

    private void rebuildCandidates(ClientPlayerEntity player) {
        candidates.clear();
        for (int i = 0; i < 36; i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isEmpty() || !isAllowed(st)) continue;
            candidates.add(new Candidate(i, st.copy()));
        }
    }

    public static boolean isAllowed(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        String name = stack.getName().getString().toLowerCase(Locale.ROOT).trim();
        // strip formatting codes
        name = name.replaceAll("§.", "");
        for (String a : ALLOWED) {
            if (name.equals(a) || name.contains(a)) return true;
        }
        return false;
    }

    private void updateHover(MinecraftClient mc) {
        if (candidates.isEmpty()) {
            hovered = -1;
            return;
        }
        double mx = mc.mouse.getX() * mc.getWindow().getScaledWidth() / Math.max(1, mc.getWindow().getWidth());
        double my = mc.mouse.getY() * mc.getWindow().getScaledHeight() / Math.max(1, mc.getWindow().getHeight());
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        double dx = mx - cx;
        double dy = my - cy;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 28) {
            // center = keep current or none
            return;
        }
        double ang = Math.atan2(dy, dx);
        if (ang < 0) ang += Math.PI * 2;
        int n = candidates.size();
        int idx = (int) (ang / (Math.PI * 2 / n)) % n;
        hovered = idx;

        // also allow scroll
        // (mouse wheel handled via key tick — optional)
    }

    private boolean swapToOffhand(MinecraftClient mc, Candidate c) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.getNetworkHandler() == null) return false;
        try {
            int slot = c.invSlot;
            ItemStack cur = p.getInventory().getStack(slot);
            if (cur.isEmpty() || !isAllowed(cur)) return false;

            // Already in offhand
            if (ItemStack.areItemsAndComponentsEqual(p.getOffHandStack(), cur)) {
                return true;
            }

            // Hotbar path: select slot -> swap hands via packet (safer pacing)
            if (slot < 9) {
                int prev = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                // small freeze before swap
                mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                        PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                        BlockPos.ORIGIN, Direction.DOWN));
                p.getInventory().setSelectedSlot(prev);
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(prev));
                return true;
            }

            // Inventory: pick up -> offhand click via interaction manager
            int syncId = p.currentScreenHandler.syncId;
            // convert inv index to container slot
            int containerSlot = slot < 9 ? slot + 36 : slot;
            mc.interactionManager.clickSlot(syncId, containerSlot, 40, net.minecraft.screen.slot.SlotActionType.SWAP, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long now = System.currentTimeMillis();
        if (statusMsg != null && now < statusUntil) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            g.drawCenteredTextWithShadow(mc.textRenderer, statusMsg, sw / 2, sh / 2 + 70, 0xFFFFFFFF);
        }

        if (openAnim < 0.02f || candidates.isEmpty()) return;

        float a = openAnim;
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int n = candidates.size();
        double radius = 72 + 6 * Math.sin(spin * 2);

        // outer ring
        int ringCol = Style.alpha(Style.ACCENT, a * 0.55f);
        int ringDim = Style.alpha(0xFF1A1A1A, a * 0.9f);
        drawRing(g, cx, cy, (int) radius + 18, 22, ringDim);
        drawRing(g, cx, cy, (int) radius + 18, 2, ringCol);

        // center disc
        GuiDraw.fillSoftCircle(g, cx, cy, 22, Style.alpha(Style.PANEL, a));
        GuiDraw.fillSoftCircle(g, cx, cy, 20, Style.alpha(0xFF0A0A0A, a));
        String tip = hovered >= 0 && hovered < n
                ? candidates.get(hovered).stack.getName().getString()
                : "Выбор";
        if (tip.length() > 16) tip = tip.substring(0, 15) + "…";
        g.drawCenteredTextWithShadow(mc.textRenderer, tip, cx, cy - 4, Style.alpha(Style.TEXT, a));
        g.drawCenteredTextWithShadow(mc.textRenderer, "отпусти — свап", cx, cy + 8,
                Style.alpha(Style.TEXT_DIM, a));

        // items on ring
        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2 + (Math.PI * 2 * i / n) + spin * 0.05;
            int ix = cx + (int) (Math.cos(ang) * radius);
            int iy = cy + (int) (Math.sin(ang) * radius);
            boolean hot = i == hovered;
            int size = hot ? 18 : 14;
            GuiDraw.fillSoftCircle(g, ix, iy, size + 4,
                    Style.alpha(hot ? Style.ACCENT : 0xFF222222, a * (hot ? 0.85f : 0.55f)));
            GuiDraw.fillSoftCircle(g, ix, iy, size + 1, Style.alpha(Style.PANEL, a));
            g.drawItem(candidates.get(i).stack, ix - 8, iy - 8);
            if (hot) {
                // soft "particle" dots
                for (int p = 0; p < 6; p++) {
                    double pa = spin * 3 + p * (Math.PI * 2 / 6);
                    int px = ix + (int) (Math.cos(pa) * (size + 6));
                    int py = iy + (int) (Math.sin(pa) * (size + 6));
                    GuiDraw.fillSoftCircle(g, px, py, 1, Style.alpha(Style.ACCENT, a * 0.7f));
                }
            }
        }
    }

    private void drawRing(DrawContext g, int cx, int cy, int r, int thick, int color) {
        // approximate ring with segments
        int steps = 48;
        for (int i = 0; i < steps; i++) {
            double a0 = (Math.PI * 2 * i) / steps;
            double a1 = (Math.PI * 2 * (i + 1)) / steps;
            for (int t = 0; t < thick; t++) {
                int rr = r - t;
                int x0 = cx + (int) (Math.cos(a0) * rr);
                int y0 = cy + (int) (Math.sin(a0) * rr);
                int x1 = cx + (int) (Math.cos(a1) * rr);
                int y1 = cy + (int) (Math.sin(a1) * rr);
                g.fill(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1) + 1, Math.max(y0, y1) + 1, color);
            }
        }
    }

    private static final class Candidate {
        final int invSlot;
        final ItemStack stack;
        Candidate(int invSlot, ItemStack stack) {
            this.invSlot = invSlot;
            this.stack = stack;
        }
    }
}
